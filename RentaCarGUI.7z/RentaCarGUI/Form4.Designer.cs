﻿namespace RentaCarGUI
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.Pretrazi = new System.Windows.Forms.Button();
            this.Cena = new System.Windows.Forms.TextBox();
            this.Boja = new System.Windows.Forms.TextBox();
            this.Godiste = new System.Windows.Forms.TextBox();
            this.Kubikaza = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Marka = new System.Windows.Forms.ComboBox();
            this.Model = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe Script", 44.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label3.Location = new System.Drawing.Point(12, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(776, 87);
            this.label3.TabIndex = 10;
            this.label3.Text = "Izaberite vaš automobil";
            // 
            // Pretrazi
            // 
            this.Pretrazi.Location = new System.Drawing.Point(167, 235);
            this.Pretrazi.Name = "Pretrazi";
            this.Pretrazi.Size = new System.Drawing.Size(72, 39);
            this.Pretrazi.TabIndex = 39;
            this.Pretrazi.Text = "Pretraži";
            this.Pretrazi.UseVisualStyleBackColor = true;
            this.Pretrazi.Click += new System.EventHandler(this.Pretrazi_Click);
            // 
            // Cena
            // 
            this.Cena.Location = new System.Drawing.Point(642, 291);
            this.Cena.Name = "Cena";
            this.Cena.Size = new System.Drawing.Size(146, 20);
            this.Cena.TabIndex = 37;
            this.Cena.TextChanged += new System.EventHandler(this.Cena_TextChanged);
            // 
            // Boja
            // 
            this.Boja.Location = new System.Drawing.Point(642, 241);
            this.Boja.Name = "Boja";
            this.Boja.Size = new System.Drawing.Size(146, 20);
            this.Boja.TabIndex = 36;
            this.Boja.TextChanged += new System.EventHandler(this.Boja_TextChanged);
            // 
            // Godiste
            // 
            this.Godiste.Location = new System.Drawing.Point(642, 191);
            this.Godiste.Name = "Godiste";
            this.Godiste.Size = new System.Drawing.Size(146, 20);
            this.Godiste.TabIndex = 35;
            this.Godiste.TextChanged += new System.EventHandler(this.Godiste_TextChanged);
            // 
            // Kubikaza
            // 
            this.Kubikaza.Location = new System.Drawing.Point(642, 141);
            this.Kubikaza.Name = "Kubikaza";
            this.Kubikaza.Size = new System.Drawing.Size(146, 20);
            this.Kubikaza.TabIndex = 34;
            this.Kubikaza.TextChanged += new System.EventHandler(this.Kubikaza_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label8.Location = new System.Drawing.Point(528, 145);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 16);
            this.label8.TabIndex = 33;
            this.label8.Text = "Kubikaža";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label7.Location = new System.Drawing.Point(528, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 16);
            this.label7.TabIndex = 32;
            this.label7.Text = "Godište";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label5.Location = new System.Drawing.Point(528, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 16);
            this.label5.TabIndex = 31;
            this.label5.Text = "Boja";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label4.Location = new System.Drawing.Point(528, 295);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 16);
            this.label4.TabIndex = 30;
            this.label4.Text = "Cena za 7 dana";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label6.Location = new System.Drawing.Point(341, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(162, 16);
            this.label6.TabIndex = 29;
            this.label6.Text = "Karakteristike automobila:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // Marka
            // 
            this.Marka.FormattingEnabled = true;
            this.Marka.Location = new System.Drawing.Point(118, 195);
            this.Marka.Name = "Marka";
            this.Marka.Size = new System.Drawing.Size(165, 21);
            this.Marka.TabIndex = 28;
            this.Marka.SelectedIndexChanged += new System.EventHandler(this.Marka_SelectedIndexChanged);
            // 
            // Model
            // 
            this.Model.FormattingEnabled = true;
            this.Model.Location = new System.Drawing.Point(118, 145);
            this.Model.Name = "Model";
            this.Model.Size = new System.Drawing.Size(165, 21);
            this.Model.TabIndex = 27;
            this.Model.SelectedIndexChanged += new System.EventHandler(this.Model_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label2.Location = new System.Drawing.Point(26, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 26;
            this.label2.Text = "Marka";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label1.Location = new System.Drawing.Point(26, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 25;
            this.label1.Text = "Model";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Pretrazi);
            this.Controls.Add(this.Cena);
            this.Controls.Add(this.Boja);
            this.Controls.Add(this.Godiste);
            this.Controls.Add(this.Kubikaza);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Marka);
            this.Controls.Add(this.Model);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Name = "Form4";
            this.Text = "IznajmiAutomobilGost";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Pretrazi;
        private System.Windows.Forms.TextBox Cena;
        private System.Windows.Forms.TextBox Boja;
        private System.Windows.Forms.TextBox Godiste;
        private System.Windows.Forms.TextBox Kubikaza;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Marka;
        private System.Windows.Forms.ComboBox Model;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}