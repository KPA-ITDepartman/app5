﻿namespace RentaCarGUI
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Model = new System.Windows.Forms.ComboBox();
            this.Marka = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Kubikaza = new System.Windows.Forms.TextBox();
            this.Godiste = new System.Windows.Forms.TextBox();
            this.Boja = new System.Windows.Forms.TextBox();
            this.Cena = new System.Windows.Forms.TextBox();
            this.IznajmiAutomobil = new System.Windows.Forms.Button();
            this.Pretrazi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe Script", 44.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label3.Location = new System.Drawing.Point(12, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(776, 87);
            this.label3.TabIndex = 9;
            this.label3.Text = "Izaberite vaš automobil";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label1.Location = new System.Drawing.Point(26, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Model";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label2.Location = new System.Drawing.Point(26, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "Marka";
            // 
            // Model
            // 
            this.Model.FormattingEnabled = true;
            this.Model.Location = new System.Drawing.Point(118, 145);
            this.Model.Name = "Model";
            this.Model.Size = new System.Drawing.Size(165, 21);
            this.Model.TabIndex = 12;
            // 
            // Marka
            // 
            this.Marka.FormattingEnabled = true;
            this.Marka.Location = new System.Drawing.Point(118, 195);
            this.Marka.Name = "Marka";
            this.Marka.Size = new System.Drawing.Size(165, 21);
            this.Marka.TabIndex = 13;
            this.Marka.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label6.Location = new System.Drawing.Point(341, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(162, 16);
            this.label6.TabIndex = 14;
            this.label6.Text = "Karakteristike automobila:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label4.Location = new System.Drawing.Point(528, 295);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 16);
            this.label4.TabIndex = 15;
            this.label4.Text = "Cena za 7 dana";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label5.Location = new System.Drawing.Point(528, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 16);
            this.label5.TabIndex = 16;
            this.label5.Text = "Boja";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label7.Location = new System.Drawing.Point(528, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 16);
            this.label7.TabIndex = 17;
            this.label7.Text = "Godište";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label8.Location = new System.Drawing.Point(528, 145);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "Kubikaža";
            // 
            // Kubikaza
            // 
            this.Kubikaza.Location = new System.Drawing.Point(642, 141);
            this.Kubikaza.Name = "Kubikaza";
            this.Kubikaza.Size = new System.Drawing.Size(146, 20);
            this.Kubikaza.TabIndex = 19;
            // 
            // Godiste
            // 
            this.Godiste.Location = new System.Drawing.Point(642, 191);
            this.Godiste.Name = "Godiste";
            this.Godiste.Size = new System.Drawing.Size(146, 20);
            this.Godiste.TabIndex = 20;
            // 
            // Boja
            // 
            this.Boja.Location = new System.Drawing.Point(642, 241);
            this.Boja.Name = "Boja";
            this.Boja.Size = new System.Drawing.Size(146, 20);
            this.Boja.TabIndex = 21;
            // 
            // Cena
            // 
            this.Cena.Location = new System.Drawing.Point(642, 291);
            this.Cena.Name = "Cena";
            this.Cena.Size = new System.Drawing.Size(146, 20);
            this.Cena.TabIndex = 22;
            // 
            // IznajmiAutomobil
            // 
            this.IznajmiAutomobil.Location = new System.Drawing.Point(531, 358);
            this.IznajmiAutomobil.Name = "IznajmiAutomobil";
            this.IznajmiAutomobil.Size = new System.Drawing.Size(204, 42);
            this.IznajmiAutomobil.TabIndex = 23;
            this.IznajmiAutomobil.Text = "Iznajmi automobil";
            this.IznajmiAutomobil.UseVisualStyleBackColor = true;
            // 
            // Pretrazi
            // 
            this.Pretrazi.Location = new System.Drawing.Point(167, 235);
            this.Pretrazi.Name = "Pretrazi";
            this.Pretrazi.Size = new System.Drawing.Size(72, 39);
            this.Pretrazi.TabIndex = 24;
            this.Pretrazi.Text = "Pretraži";
            this.Pretrazi.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Pretrazi);
            this.Controls.Add(this.IznajmiAutomobil);
            this.Controls.Add(this.Cena);
            this.Controls.Add(this.Boja);
            this.Controls.Add(this.Godiste);
            this.Controls.Add(this.Kubikaza);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Marka);
            this.Controls.Add(this.Model);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Name = "Form3";
            this.Text = "IznajmiAutomobil";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Model;
        private System.Windows.Forms.ComboBox Marka;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Kubikaza;
        private System.Windows.Forms.TextBox Godiste;
        private System.Windows.Forms.TextBox Boja;
        private System.Windows.Forms.TextBox Cena;
        private System.Windows.Forms.Button IznajmiAutomobil;
        private System.Windows.Forms.Button Pretrazi;
    }
}