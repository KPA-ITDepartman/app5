﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentaCarGUI
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void IznajmiAutomobil_Click(object sender, EventArgs e)
        {

        }

        private void Cena_TextChanged(object sender, EventArgs e)
        {

        }

        private void Boja_TextChanged(object sender, EventArgs e)
        {

        }

        private void Godiste_TextChanged(object sender, EventArgs e)
        {

        }

        private void Kubikaza_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Marka_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Model_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Pretrazi_Click(object sender, EventArgs e)
        {

        }
    }
}
