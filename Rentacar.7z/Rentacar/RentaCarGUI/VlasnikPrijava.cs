﻿using System;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace RentaCarGUI
{
    public partial class VlasnikPrijava : Form
    {
        OracleConnection connection;
        OracleCommand command;
        OracleDataReader reader;

        public VlasnikPrijava()
        {
            InitializeComponent();
        }

        private void bOK_Click(object sender, EventArgs e)
        {
            try
            {
                string ime = tbIme.Text.Trim().ToLower();
                string prezime = tbPrezime.Text.Trim().ToLower();
                int id = Convert.ToInt32(tbID.Text);

                using(connection = new OracleConnection(Pocetna.connectionString))
                {
                    connection.Open();
                    string upit = "SELECT * FROM pim.vlasnici WHERE ime = '" + ime + "' AND prezime = '" + prezime + "' AND id_vlasnik = " + id;
                    command = new OracleCommand(upit, connection);
                    reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        Vlasnik v = new Vlasnik();
                        v.ShowDialog();
                    }
                    else
                        throw new Exception();
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Greška.");
            }
        }
    }
}
