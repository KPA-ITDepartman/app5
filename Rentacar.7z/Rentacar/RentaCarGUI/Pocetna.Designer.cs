﻿namespace RentaCarGUI
{
    partial class Pocetna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bGost = new System.Windows.Forms.Button();
            this.bDalje = new System.Windows.Forms.Button();
            this.bRegistrujSe = new System.Windows.Forms.Button();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbLozinka = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.linkVlasnik = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // bGost
            // 
            this.bGost.ForeColor = System.Drawing.Color.Black;
            this.bGost.Location = new System.Drawing.Point(177, 389);
            this.bGost.Name = "bGost";
            this.bGost.Size = new System.Drawing.Size(137, 27);
            this.bGost.TabIndex = 4;
            this.bGost.Text = "Nastavi kao gost";
            this.bGost.UseVisualStyleBackColor = true;
            this.bGost.Click += new System.EventHandler(this.bGost_Click);
            // 
            // bDalje
            // 
            this.bDalje.ForeColor = System.Drawing.Color.Black;
            this.bDalje.Location = new System.Drawing.Point(177, 263);
            this.bDalje.Name = "bDalje";
            this.bDalje.Size = new System.Drawing.Size(137, 27);
            this.bDalje.TabIndex = 2;
            this.bDalje.Text = "Dalje";
            this.bDalje.UseVisualStyleBackColor = true;
            this.bDalje.Click += new System.EventHandler(this.bDalje_Click);
            // 
            // bRegistrujSe
            // 
            this.bRegistrujSe.ForeColor = System.Drawing.Color.Black;
            this.bRegistrujSe.Location = new System.Drawing.Point(177, 356);
            this.bRegistrujSe.Name = "bRegistrujSe";
            this.bRegistrujSe.Size = new System.Drawing.Size(137, 27);
            this.bRegistrujSe.TabIndex = 3;
            this.bRegistrujSe.Text = "Registruj se";
            this.bRegistrujSe.UseVisualStyleBackColor = true;
            this.bRegistrujSe.Click += new System.EventHandler(this.bRegistrujSe_Click);
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(177, 189);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(210, 20);
            this.tbEmail.TabIndex = 0;
            // 
            // tbLozinka
            // 
            this.tbLozinka.Location = new System.Drawing.Point(177, 226);
            this.tbLozinka.Name = "tbLozinka";
            this.tbLozinka.Size = new System.Drawing.Size(210, 20);
            this.tbLozinka.TabIndex = 1;
            this.tbLozinka.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(62, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "E-mail";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(62, 230);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Lozinka";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe Script", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label3.Location = new System.Drawing.Point(130, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(471, 104);
            this.label3.TabIndex = 8;
            this.label3.Text = "Dobro došli";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.Pink;
            this.label4.Location = new System.Drawing.Point(174, 419);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(318, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "*Ukoliko nastavite kao gost moći ćete samo da pogledate ponudu";
            // 
            // linkVlasnik
            // 
            this.linkVlasnik.AutoSize = true;
            this.linkVlasnik.LinkColor = System.Drawing.Color.Yellow;
            this.linkVlasnik.Location = new System.Drawing.Point(2, 428);
            this.linkVlasnik.Name = "linkVlasnik";
            this.linkVlasnik.Size = new System.Drawing.Size(106, 13);
            this.linkVlasnik.TabIndex = 5;
            this.linkVlasnik.TabStop = true;
            this.linkVlasnik.Text = "Prijavi se kao vlasnik";
            this.linkVlasnik.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkVlasnik_LinkClicked);
            // 
            // Pocetna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(727, 450);
            this.Controls.Add(this.linkVlasnik);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbLozinka);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.bRegistrujSe);
            this.Controls.Add(this.bDalje);
            this.Controls.Add(this.bGost);
            this.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.Name = "Pocetna";
            this.Text = "IznajmiAutomobil";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bGost;
        private System.Windows.Forms.Button bDalje;
        private System.Windows.Forms.Button bRegistrujSe;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbLozinka;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.LinkLabel linkVlasnik;
    }
}

