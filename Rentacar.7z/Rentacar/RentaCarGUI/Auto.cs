﻿namespace RentaCarGUI
{
    class Auto
    {
        public string marka, model, boja;
        public  int kubikaza, godiste, cena, id;

        public Auto(int id, string marka, string model, int kubikaza, int godiste, string boja, int cena)
        {
            this.id = id;
            this.marka = marka;
            this.model = model;
            this.kubikaza = kubikaza;
            this.godiste = godiste;
            this.boja = boja;
            this.cena = cena;
        }

        public Auto(string marka, string model, int kubikaza, int godiste, string boja, int cena)
        {
            this.marka = marka;
            this.model = model;
            this.kubikaza = kubikaza;
            this.godiste = godiste;
            this.boja = boja;
            this.cena = cena;
        }
        public Auto(string marka)
        {
            this.marka = marka;
        }
    }
}
