﻿using System;
using System.Collections.Generic;
using Oracle.DataAccess.Client;

using System.Windows.Forms;

namespace RentaCarGUI
{
    public partial class Gost : Form
    {
        List<Auto> lista;
        OracleConnection connection;
        OracleCommand command;
        OracleDataReader reader;

        public Gost()
        {
            InitializeComponent();
            lista = new List<Auto>();
        }

        private void isprazniInformacije()
        {
            tbKubikaza.Text = "";
            tbGodiste.Text = "";
            tbBoja.Text = "";
            tbCena.Text = "";
        }


        private void Iznajmljivanje_Load(object sender, EventArgs e)
        {
            string upit = "SELECT marka, model, kubikaza, godiste, boja, cena FROM pim.auto";
            using (connection = new OracleConnection(Pocetna.connectionString))
            {
                connection.Open();
                command = new OracleCommand(upit, connection);
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string marka = reader[0].ToString().Trim().ToUpper();
                    string model = reader[1].ToString();
                    int kubikaza = Convert.ToInt32(reader[2]);
                    int godiste = Convert.ToInt32(reader[3]);
                    string boja = reader[4].ToString();
                    int cena = Convert.ToInt32(reader[5]);
                    Auto a = new Auto(marka, model, kubikaza, godiste, boja, cena);
                    lista.Add(a);
                }
            }

            foreach (Auto a in lista)
            {
                bool sadrzi = false;
                foreach (var item in cbMarka.Items)
                {
                    if (item.ToString() == a.marka)
                        sadrzi = true;
                }
                if (!sadrzi)
                    cbMarka.Items.Add(a.marka);
            }
        }



        private void cbMarka_SelectedIndexChanged(object sender, EventArgs e)
        {
            isprazniInformacije();
            string izabranaMarka = cbMarka.SelectedItem.ToString();
            cbModel.Items.Clear();
            foreach (Auto a in lista)
            {
                if (a.marka == izabranaMarka)
                    cbModel.Items.Add(a.model);
            }
        }


        private void cbModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            isprazniInformacije();
        }



        private void Pretrazi_Click(object sender, EventArgs e)
        {
            try
            {
                string marka = cbMarka.SelectedItem.ToString();
                string model = cbModel.SelectedItem.ToString();

                foreach (Auto a in lista)
                {
                    if (a.marka == marka && a.model == model)
                    {
                        tbKubikaza.Text = a.kubikaza.ToString();
                        tbGodiste.Text = a.godiste.ToString();
                        tbBoja.Text = a.boja;
                        tbCena.Text = a.cena.ToString();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Morate izabrati marku i model.");
            }
        }

        private void Gost_Load(object sender, EventArgs e)
        {
            string upit = "SELECT marka, model, kubikaza, godiste, boja, cena FROM pim.auto";
            using (connection = new OracleConnection(Pocetna.connectionString))
            {
                connection.Open();
                command = new OracleCommand(upit, connection);
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string marka = reader[0].ToString().Trim().ToUpper();
                    string model = reader[1].ToString();
                    int kubikaza = Convert.ToInt32(reader[2]);
                    int godiste = Convert.ToInt32(reader[3]);
                    string boja = reader[4].ToString();
                    int cena = Convert.ToInt32(reader[5]);
                    Auto a = new Auto(marka, model, kubikaza, godiste, boja, cena);
                    lista.Add(a);
                }
            }

            foreach (Auto a in lista)
            {
                bool sadrzi = false;
                foreach (var item in cbMarka.Items)
                {
                    if (item.ToString() == a.marka)
                        sadrzi = true;
                }
                if (!sadrzi)
                    cbMarka.Items.Add(a.marka);
            }
        }

        private void cbMarka_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            isprazniInformacije();
            string izabranaMarka = cbMarka.SelectedItem.ToString();
            cbModel.Items.Clear();
            foreach (Auto a in lista)
            {
                if (a.marka == izabranaMarka)
                    cbModel.Items.Add(a.model);
            }
        }

        private void cbModel_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            isprazniInformacije();
        }

        private void bPretrazi_Click(object sender, EventArgs e)
        {
            try
            {
                string marka = cbMarka.SelectedItem.ToString();
                string model = cbModel.SelectedItem.ToString();

                foreach (Auto a in lista)
                {
                    if (a.marka == marka && a.model == model)
                    {
                        tbKubikaza.Text = a.kubikaza.ToString();
                        tbGodiste.Text = a.godiste.ToString();
                        tbBoja.Text = a.boja;
                        tbCena.Text = a.cena.ToString();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Morate izabrati marku i model.");
            }
        }
    }
}
