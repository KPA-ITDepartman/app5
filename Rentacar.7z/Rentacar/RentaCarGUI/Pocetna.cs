﻿using System;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace RentaCarGUI
{
    public partial class Pocetna : Form
    {
        public static string connectionString = "Data source = (DESCRIPTION = (ADDRESS_LIST =(ADDRESS = (PROTOCOL = IPC)(KEY = EXTPROC1)))" +
        "(CONNECT_DATA =(SID = xe)(PRESENTATION = RO)));User Id = system; Password = 123;";

        OracleConnection connection;
        OracleCommand command;
        OracleDataReader reader;

        public Pocetna()
        {
            InitializeComponent();
        }

        private void bDalje_Click(object sender, EventArgs e)
        {
            string mail = tbEmail.Text;
            string pass = tbLozinka.Text;

            if(mail == "" || pass == "")
            {
                MessageBox.Show("Niste popunili polja za prijavu.");
                return;
            }

            string upit = "SELECT * FROM pim.korisnik WHERE email = '" + mail + "' AND lozinka = '" + pass + "'";

            using(connection = new OracleConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    command = new OracleCommand(upit, connection);
                    reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        tbEmail.Text = "";
                        tbLozinka.Text = "";
                        Iznajmljivanje i = new Iznajmljivanje(mail);
                        i.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Neispravan email i/ili lozinka.");
                        tbEmail.Text = "";
                        tbLozinka.Text = "";
                        return;
                    }
                }
                catch(OracleException)
                {
                    
                }
            }
        }

        private void bRegistrujSe_Click(object sender, EventArgs e)
        {
            Registracija reg = new Registracija();
            reg.ShowDialog();
        }

        private void bGost_Click(object sender, EventArgs e)
        {
            Gost g = new Gost();
            g.ShowDialog();
        }

        private void linkVlasnik_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            VlasnikPrijava v = new VlasnikPrijava();
            v.ShowDialog();
        }
    }
}
