﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using Oracle.DataAccess.Client;

namespace RentaCarGUI
{
    public partial class Iznajmljivanje : Form
    {
        List<Auto> lista;
        OracleConnection connection;
        OracleCommand command;
        OracleDataReader reader;

        string email;

        private void isprazniInformacije()
        {
            tbKubikaza.Text = "";
            tbGodiste.Text = "";
            tbBoja.Text = "";
            tbCena.Text = "";
        }

        public Iznajmljivanje(string email)
        {
            InitializeComponent();
            lista = new List<Auto>();
            this.email = email;
        }


        private void Iznajmljivanje_Load(object sender, EventArgs e)
        {
            string upit = "SELECT id_auto, marka, model, kubikaza, godiste, boja, cena FROM pim.auto";
            using (connection = new OracleConnection(Pocetna.connectionString))
            {
                connection.Open();
                command = new OracleCommand(upit, connection);
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader[0].ToString());
                    string marka = reader[1].ToString().Trim().ToUpper();
                    string model = reader[2].ToString();
                    int kubikaza = Convert.ToInt32(reader[3]);
                    int godiste = Convert.ToInt32(reader[4]);
                    string boja = reader[5].ToString();
                    int cena = Convert.ToInt32(reader[6]);
                    Auto a = new Auto(id,marka, model, kubikaza, godiste, boja, cena);
                    lista.Add(a);
                }
            }

            foreach (Auto a in lista)
            {
                bool sadrzi = false;
                foreach (var item in cbMarka.Items)
                {
                    if (item.ToString() == a.marka)
                        sadrzi = true;
                }
                if (!sadrzi)
                    cbMarka.Items.Add(a.marka);
            }
        }



        private void cbMarka_SelectedIndexChanged(object sender, EventArgs e)
        {
            isprazniInformacije();
            string izabranaMarka = cbMarka.SelectedItem.ToString();
            cbModel.Items.Clear();
            foreach (Auto a in lista)
            {
                if (a.marka == izabranaMarka)
                    cbModel.Items.Add(a.model);
            }
        }


        private void cbModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            isprazniInformacije();
        }



        private void Pretrazi_Click(object sender, EventArgs e)
        {
            try
            {
                string marka = cbMarka.SelectedItem.ToString();
                string model = cbModel.SelectedItem.ToString();

                foreach (Auto a in lista)
                {
                    if(a.marka == marka && a.model == model)
                    {
                        tbKubikaza.Text = a.kubikaza.ToString();
                        tbGodiste.Text = a.godiste.ToString();
                        tbBoja.Text = a.boja;
                        tbCena.Text = a.cena.ToString();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Morate izabrati marku i model.");
            }
        }

        private void IznajmiAutomobil_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbMarka.SelectedIndex < 0 || cbModel.SelectedIndex < 0)
                    throw new Exception("Morate izabrati vozilo.");
                string marka = cbMarka.SelectedItem.ToString();
                string model = cbModel.SelectedItem.ToString();
                int idAuta = 0;
                foreach (Auto auto in lista)
                {
                    if (auto.marka == marka && auto.model == model)
                        idAuta = auto.id;
                }
                string upit = "SELECT auto FROM pim.iznajmljeno";
                using (connection = new OracleConnection(Pocetna.connectionString))
                {
                    int id = 0;
                    connection.Open();
                    command = new OracleCommand(upit, connection);
                    reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        id = Convert.ToInt32(reader[0]);
                            if (id == idAuta)
                                throw new Exception("Vozilo je trenutno iznajmljeno.");
                    }
                    upit = "INSERT INTO pim.iznajmljeno VALUES('" + email + "', " + idAuta + ")";
                    command = new OracleCommand(upit, connection);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Uspešno ste izajmili vozilo.");
                    }
                }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
