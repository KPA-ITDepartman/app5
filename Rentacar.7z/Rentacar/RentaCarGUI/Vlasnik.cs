﻿using System;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace RentaCarGUI
{
    public partial class Vlasnik : Form
    {
        OracleConnection connection;
        OracleCommand command;
        OracleDataReader reader;

        public Vlasnik()
        {
            InitializeComponent();
        }

        private void Vlasnik_Load(object sender, EventArgs e)
        {
            try { 
            string upit = "SELECT pim.korisnik.ime, pim.korisnik.prezime, pim.auto.marka, pim.auto.model FROM pim.korisnik INNER JOIN pim.iznajmljeno ON pim.iznajmljeno.email_iznajmioca = pim.korisnik.email INNER JOIN pim.auto ON pim.auto.id_auto = pim.iznajmljeno.auto";
            using (connection = new OracleConnection(Pocetna.connectionString))
            {
                connection.Open();
                command = new OracleCommand(upit, connection);
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string item = reader[0].ToString() + " " + reader[1].ToString() + " -- " + reader[2].ToString() + " " + reader[3].ToString();
                    listBox.Items.Add(item);
                }
            }
                }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
