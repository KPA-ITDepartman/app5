﻿using System;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace RentaCarGUI
{
    public partial class Registracija : Form
    {
        OracleConnection connection;
        OracleCommand command;

        private bool ispravanMail(string email)
        {
            email.Trim();
            if (!email.Contains("@") || !email.Contains("."))
                return false;
            if (email.IndexOf('@') < 2 && email.IndexOf('@') != (email.Length - 1))
                return false;
            if (email.IndexOf('.') == (email.Length - 1))
                return false;

            return true;
        }

        private bool isteLozinke(string p1, string p2)
        {
            p1.Trim();
            p2.Trim();
            if (p1 == p2)
                return true;
            else
                throw new Exception("Lozinke nisu iste.");
        }

        private bool ispravanUnos(string ime, string prezime, string email, string p1, string p2)
        {
            if (string.IsNullOrEmpty(ime) || string.IsNullOrEmpty(prezime))
                throw new Exception("Sva polja moraju biti popunjena.");
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(p1) || string.IsNullOrEmpty(p2))
                throw new Exception("Sva polja moraju biti popunjena.");
            if (!isteLozinke(p1, p2))
                throw new Exception("Lozinke nisu iste.");
            if (!ispravanMail(email))
                throw new Exception("Neispravan email.");
            if (!checkPravila.Checked)
                throw new Exception("Morate se slagati sa pravilima firme");

            return true;
        }

        public Registracija()
        {
            InitializeComponent();
        }

        private void bRegistrujSe_Click(object sender, EventArgs e)
        {
            try
            {
                string ime = tbIme.Text.Trim();
                string prezime = tbPrezime.Text.Trim();
                string email = tbEmail.Text.Trim();
                string p1 = tbLozinka1.Text.Trim();
                string p2 = tbLozinka2.Text.Trim();

                if (ispravanUnos(ime, prezime, email, p1, p2))
                {
                    string upit = "INSERT INTO pim.korisnik VALUES('" + ime + "','" + prezime + "','" + email + "','" + p1 + "')";
                    using(connection = new OracleConnection(Pocetna.connectionString))
                    {
                        connection.Open();
                        command = new OracleCommand(upit, connection);
                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Uspešno ste se registrovali.");
                }
            }
            catch (OracleException)
            {
                MessageBox.Show("Uneta email adresa je već registrovana.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
